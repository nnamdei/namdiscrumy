from django.apps import AppConfig


class NamdiscrumyConfig(AppConfig):
    name = 'namdiscrumy'
